import React, { Component } from 'react';
import App from './App';

class AppContainer extends Component {
  render() {
    return <App />;
  }
}

export default AppContainer;
