import React from 'react';

const Hangman = () => (
  <div>
    <h2>Let's play Hangman</h2>
  </div>
);

export default Hangman;
