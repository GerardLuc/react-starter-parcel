import React from 'react';

const Shifumi = () => (
  <div>
    <h2>Let's play Shifumi</h2>
  </div>

  
);

export default Shifumi;
