import React from 'react';

const Home = () => (
  <div className="home">
    <h2>Navigate through your application</h2>
  </div>
);

export default Home;
